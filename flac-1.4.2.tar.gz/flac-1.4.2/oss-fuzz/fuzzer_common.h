extern int alloc_check_threshold, alloc_check_counter;
int alloc_check_threshold = INT32_MAX, alloc_check_counter = 0;
